=== Easy Property Listings Extension - Listing Unlimited ===
Author URI: http://www.realestateconnected.com.au/
Plugin URI: https://easypropertylistings.com.au/extensions/listing-unlimited/
Contributors: mervb1
Donate link: https://easypropertylistings.com.au/support-the-site/
Tags: extension, easy property listings, listings, widget, upload, custom fields
Requires at least: 3.3
Tested up to: 4.3.1

Stable Tag: 2.1

License: GNU Version 2 or Any Later Version

Add additional customisable info and PDF file to your listings that are imported from a third party.

== Description ==

Add additional customisable info to your listings that are imported from a third party.

== Installation ==

1. Upload plugin zip contents to wp-contents/plugin/ directory and activate the plugin.


== Change log ==

= 2.1 September 18, 2015 =

New: Ability to add PDF file to listings.
New: Textdomian for translations.
New: Custom Fields increased from 10 to 20.
Fix: Widget construct correction for WordPress 4.3 compatibility.

= 2.0.1 May 8, 2015 =

Tweak: Corrected file encoding.

= 2.0: March 3, 2015 =

Initial public release.