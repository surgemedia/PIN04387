<?php
/**
 * Archive Template for Property Custom Post Type : property
 */

do_action('epl_render_archive_post');
