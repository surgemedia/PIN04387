<?php
/**
 * Single Template for Property Custom Post Type : property
 */

do_action('epl_render_single_post');
