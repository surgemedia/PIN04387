<?php
/*
 * Settings Fields
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

$epl_settings = epl_settings();
extract($epl_settings);
