/* db credentials */
DEFINE('DB_USER', 'root' );
DEFINE('DB_PASS', 'root' );
DEFINE('DB_NAME', 'root' );
DEFINE('DB_HOST', 'localhost' );
/* db credentials */
DEFINE('DB_USER', 'root' );
DEFINE('DB_PASS', 'root' );
DEFINE('DB_NAME', 'feedsync' );
DEFINE('DB_HOST', 'localhost' );
/* db credentials */
DEFINE('DB_USER', 'root' );
DEFINE('DB_PASS', 'root' );
DEFINE('DB_NAME', 'feedsync' );
DEFINE('DB_HOST', 'localhost' );
