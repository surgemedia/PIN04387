=== Easy Property Listings Extension - Business Directory ===
Author URI: http://www.realestateconnected.com.au/
Plugin URI: https://easypropertylistings.com.au/extensions/business-directory/
Contributors: mervb1
Donate link: https://easypropertylistings.com.au/support-the-site/
Tags: extension, easy property listings, business listings, widget
Requires at least: 3.3
Tested up to: 4.3.1

Stable Tag: 2.0.1

License: GNU Version 2 or Any Later Version

Supercharge your networking like never before with a Business Directory plugin!

== Description ==

This is one of the widely used and most popular plugins. You should have one too! It is a must-have! Create any kind of directory for your real estate listings with this Business Directory plugin. Link to local businesses and see your business flare into greater heights. This Business Directory plugin will boost interaction and pump up deals easily. Build an address book to keep customers at bay and for fluid business dealings. Truly a plugin with an exceptional and cost- effective value! Generate profits and results with this powerful plugin now.

== Installation ==

1. Upload plugin zip contents to wp-contents/plugin/ directory and activate the plugin.
2. Add your awards from Dashboard > Awards


== Change log ==

= 2.0.1: September 18, 2015 =

* Fix: Widget construct fix for WordPress 4.3
* Tweak: Text domain for translation support.

= 2.0: March 3, 2015 =

* New: Added support for Easy Property Listings 2.0

= 1.0.3, September 8, 2014 =

* Fix: Redeclare image size if Easy Property Listings is active during update

= 1.0.2, June 2, 2014 =

* Tweak: Updated settings to new format
* Tweak: Updated location taxonomy

= 1.0.1, May 26, 2014 =

* Added Updater
* Added Business Category Widget

= 1.0.0, May 22, 2014 =
* Initial release.