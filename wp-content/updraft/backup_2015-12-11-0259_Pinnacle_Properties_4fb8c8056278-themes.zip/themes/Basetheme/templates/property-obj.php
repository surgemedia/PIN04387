<article <?php post_class(); ?>>
	
			<img src="https://unsplash.it/960/730/?random" alt="" >
			<div class="overlay">
				<h1 class="title"></h1>
				<div class="property-obj">
					<span class="title"></span>
					<a href="" class="details"></a>
					<ul>
						<li><a href=""><i></i><span></span></a></li>
						<li><a href=""><i></i><span></span></a></li>
						<li><a href=""><i></i><span></span></a></li>
					</ul>
				</div>
			</div>
	
</article>
